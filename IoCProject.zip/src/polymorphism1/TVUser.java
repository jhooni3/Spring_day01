package polymorphism1;

public class TVUser {
	public static void main(String[] args) {
		LgTV tv = new LgTV();
		tv.turnOn();
		tv.soundUp();
		tv.soundDown();
		tv.turnOff();
	}
}
