package polymorphism4;

public interface TV {

	void powerOn();

	void powerOff();

	void volumeUp();

	void volumeDown();

}