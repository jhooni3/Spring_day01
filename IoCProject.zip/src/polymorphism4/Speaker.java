package polymorphism4;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}