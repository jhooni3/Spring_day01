package polymorphism3;

public interface TV {

	void powerOn();

	void powerOff();

	void volumeUp();

	void volumeDown();

}