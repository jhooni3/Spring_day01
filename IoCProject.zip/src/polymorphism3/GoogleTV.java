package polymorphism3;

public class GoogleTV implements TV {
	private int price;
	
	public GoogleTV() {
		System.out.println("===> GoogleTV 생성");
	}
	public void 초기화() {
		System.out.println("---> 초기화()");
		this.price = 1700000;
	}
	public void 자원해제() {
		System.out.println("---> 자원해제()");
		this.price = 0;
	}
	public void powerOn() {
		System.out.println("GoogleTV---전원 켠다." + price);
	}
	public void powerOff() {
		System.out.println("GoogleTV---전원 끈다.");
	}
	public void volumeUp() {
		System.out.println("GoogleTV---소리 올린다.");
	}
	public void volumeDown() {
		System.out.println("GoogleTV---소리 내린다.");
	}
}
